import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../product.service';
import { Products } from 'src/app/product.model';
import Utility from '../../shared/utility';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  selectedCategory: string;
  productList: Products[] = [];
  product: Products;
  addedProductToCart: Products[] = [];
  displayProduct: Products[];

  constructor( private route: ActivatedRoute, private productService: ProductService) {}

  ngOnInit(): void {
    // get product list from service
    this.productList = this.productService.getproductList();
    console.log('productlist', this.productList);
    
    // subscribe to latest navigation from route params
    this.route.paramMap.subscribe((params: any) => {
      this.selectedCategory = Utility.capitalizeFirstLetter(params.params.id);
      
      // set selected product by name
      if(this.selectedCategory !== 'All') {
        this.displayProduct = [];
        this.product = this.productList.find(item => item.name === params.params.id);
        this.displayProduct.push(this.product);
        console.log('Product', this.displayProduct);
      } else {
        this.displayProduct = [...this.productList]; // display all product
      }
    }); 
  }

  //TODO: add array items to cart array and display in template
  addProductToCart(product) {
    this.addedProductToCart.push(product)
    console.log(this.addedProductToCart);
  }

}
